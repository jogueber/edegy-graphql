rootProject.name = "graphql-client"
