package com.netlight.berlin.edgey.graphqlclient

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GraphqlClientApplicationTests {

	@Test
	fun contextLoads() {
	}

}
